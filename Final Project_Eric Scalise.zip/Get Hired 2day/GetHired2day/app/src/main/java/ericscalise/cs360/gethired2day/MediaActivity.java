package ericscalise.cs360.gethired2day;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
//Import Youtube player classes
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class MediaActivity extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener,
YouTubePlayer.PlayerStateChangeListener, YouTubePlayer.PlaybackEventListener

{
    //Variables for Youtube player, API key, and Video to play once loaded
    YouTubePlayerView playerView;
    String API_KEY = "AIzaSyBk83HDNCG2cCRPU67q557ZSEL1eyAYET8";
    String VIDEO_ID = "kayOhGRcNt4";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media);
        playerView = (YouTubePlayerView) findViewById(R.id.playerview);
        playerView.initialize(API_KEY, this);
    }
//What happens once video is initialized
    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
        youTubePlayer.setPlayerStateChangeListener(this);
        youTubePlayer.setPlaybackEventListener(this);

        if(!b)
        {
            youTubePlayer.cueVideo(VIDEO_ID);
        }

    }
    //All below are required for player to work successfully as described by Android Studio.
    @Override
    public void onPlaying() {

    }

    @Override
    public void onLoaded(String s) {

    }

    @Override
    public void onLoading() {

    }

    @Override
    public void onVideoEnded() {

    }

    @Override
    public void onVideoStarted() {

    }

    @Override
    public void onError(YouTubePlayer.ErrorReason errorReason) {

    }

    @Override
    public void onAdStarted() {

    }

    @Override
    public void onBuffering(boolean b) {

    }

    @Override
    public void onPaused() {

    }

    @Override
    public void onStopped() {

    }

    @Override
    public void onSeekTo(int i) {

    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

    }
}
