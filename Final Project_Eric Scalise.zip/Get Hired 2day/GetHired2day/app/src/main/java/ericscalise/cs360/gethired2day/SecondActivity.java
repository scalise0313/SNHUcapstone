package ericscalise.cs360.gethired2day;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private Button ePort;
    private Button maps;
    private Button myMedia;
    private Button myFacebook;
    private Button myCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        ePort = findViewById(R.id.Button1);

        ePort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_ePortfolio();
            }
        });

        maps = findViewById(R.id.maps);

        maps.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                open_MapsActivity();
            }
        });

        myMedia = findViewById(R.id.myMedia);

        myMedia.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                open_mediaActivity();
            }
        });

        myFacebook = findViewById(R.id.facebook);

        myFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open_facebookActivity();
            }
        });

        myCalendar = findViewById(R.id.calendar);

        myCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open_calendarActivity();
            }
        });

    }
    private void open_ePortfolio(){
        Intent intent = new Intent(this, ePortfolio.class);
        startActivity(intent);

    }

    private void open_MapsActivity(){
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }

    private void open_mediaActivity(){
        Intent intent = new Intent(this, MediaActivity.class);
        startActivity(intent);
    }

    private void open_facebookActivity(){
        Intent intent = new Intent(this, facebookActivity.class);
        startActivity(intent);
    }
    private void open_calendarActivity(){
        Intent intent = new Intent(this, calendaryActivity.class);
        startActivity(intent);
    }


}
