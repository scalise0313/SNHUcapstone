package ericscalise.cs360.gethired2day;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class calendaryActivity extends AppCompatActivity {

    CalendarView calendarView;
    TextView myDate;
    Button  calBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendary);

        calendarView =findViewById(R.id.calendarView);
        myDate       =findViewById(R.id.myDate);
        calBtn       =findViewById(R.id.calBtn);

        calBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                    @Override
                    public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                        String date = dayOfMonth + "/" + (month +1) + "/" + year;

                        String message = getString(R.string.my_date);
                        message += date;

                        myDate.setText(message);
                    }
                });
            }
        });



    }
}
