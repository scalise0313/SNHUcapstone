package ericscalise.cs360.gethired2day;

public class ePortClass {
    // instance variables
    private int var_id;
    private String var_loc;
    private int var_pnum;
    private String var_wrkhs;
    private String var_ed;
    private String var_ref;

    // Empty constructor
    public ePortClass() {}

    // constructor with all six variables
    public ePortClass(int id, String location, int phoneNum, String wrkht, String edu, String refs) {
        this.var_id = id;
        this.var_loc= location;
        this.var_pnum = phoneNum;
        this.var_wrkhs = wrkht;
        this.var_ed = edu;
        this.var_ref = refs;
    }
    // constructor without id
    public ePortClass( String location, int phoneNum, String wrkht, String edu, String refs) {
        this.var_loc= location;
        this.var_pnum = phoneNum;
        this.var_wrkhs = wrkht;
        this.var_ed = edu;
        this.var_ref = refs;
    }
    // setters (mutator's)
    public void setID(int id) { this.var_id = id; }
    public void setLoc(String location) { this.var_loc = location; }
    public void setNums(int phoneNum) { this.var_pnum = phoneNum; }
    public void setWrkht(String workHist) { this.var_wrkhs= workHist; }
    public void setEdu(String education) { this.var_ed = education; }
    public void setRefs(String references) { this.var_ref = references; }

    // getters (accessors)
    public int getID() { return this.var_id; }
    public String getLoc() { return this.var_loc; }
    public int getNums() { return this.var_pnum; }
    public String getWrkht () { return this.var_wrkhs;}
    public String getEdu () { return this.var_ed;}
    public String getRefs () { return this.var_ref;}
}
