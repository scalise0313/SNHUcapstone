package ericscalise.cs360.gethired2day;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ePortfolio extends AppCompatActivity {
    TextView idView;
    EditText locBox;
    EditText numBox;
    EditText wrkhtBox;
    EditText eduBox;
    EditText refBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_e_portfolio);
        idView = (TextView) findViewById(R.id.personID);
        locBox = (EditText) findViewById(R.id.perLocation);
        numBox = (EditText) findViewById(R.id.phonenum);
        wrkhtBox = (EditText) findViewById(R.id.wrkHist);
        eduBox = (EditText) findViewById(R.id.education);
        refBox = (EditText) findViewById(R.id.references);
    }
    public void addInfo(View view) {
        ePortHandler ePortHandler = new ePortHandler(this, null, null, 1);
        int id = Integer.parseInt(idView.getText().toString());
        int phonenum = Integer.parseInt(numBox.getText().toString());
        ePortClass ePortClass = new ePortClass(id, locBox.getText().toString(),phonenum, wrkhtBox.getText().toString(), eduBox.getText().toString(), refBox.getText().toString());
        ePortHandler.addInfo(ePortClass);
        locBox.setText("");
        numBox.setText("");
        wrkhtBox.setText("");
        eduBox.setText("");
        refBox.setText("");
    }
    public void searchInfo(View view) {
        ePortHandler ePortHandler = new ePortHandler(this, null, null, 1);
        ePortClass ePortClass = ePortHandler.searchInfo(locBox.getText().toString());
        if (ePortClass != null) {
            idView.setText(String.valueOf(ePortClass.getID()));
            locBox.setText(String.valueOf(ePortClass.getLoc()));
            numBox.setText(String.valueOf(ePortClass.getNums()));
            wrkhtBox.setText(String.valueOf(ePortClass.getWrkht()));
            eduBox.setText(String.valueOf(ePortClass.getEdu()));
            refBox.setText(String.valueOf(ePortClass.getRefs()));
        } else {
            idView.setText("Record Not Found.");
        }
    }
    public void deleteInfo(View view) {
        ePortHandler ePortHandler = new ePortHandler(this, null, null, 1);
        boolean result = ePortHandler.deleteInfo(locBox.getText().toString());
        if (result)
        {
            idView.setText("Record Deleted");
            locBox.setText("");
            numBox.setText("");
            wrkhtBox.setText("");
            eduBox.setText("");
            refBox.setText("");
        }
        else
            idView.setText("Record Not Found. ");
    }
}
