package ericscalise.cs360.gethired2day;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ePortHandler extends SQLiteOpenHelper {

    // database name and version
    private static final int DB_VER = 1;
    private static final String DB_NAME = "ePort.db";
    // table
    public static final String TABLE_ePortfolio = "ePortfolio";
    // columns
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_LOC = "Location";
    public static final String COLUMN_PNUM = "PhoneNumber";
    public static final String COLUMN_WRKHT = "WorkHistory";
    public static final String COLUMN_EDU = "Education";
    public static final String COLUMN_REF = "References";
    // constructor
    public ePortHandler(Context context, String name,
                        SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, DB_NAME, factory, DB_VER);
    }
    // This method creates the Dogs table when the DB is initialized.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_ePortfolio_TABLE = "CREATE TABLE " +
                TABLE_ePortfolio + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY," +
                COLUMN_LOC + " TEXT," +
                COLUMN_PNUM + " INTEGER," +
                COLUMN_WRKHT + " TEXT, " +
                COLUMN_EDU + " TEXT, " +
                COLUMN_REF + "TEXT  " + ")";
        db.execSQL(CREATE_ePortfolio_TABLE);
    }
    // This method closes an open DB if a new one is created.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ePortfolio);
        onCreate(db);
    }
    // This method is used to adds info record to the database.
    public void addInfo(ePortClass ePortClass) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_LOC, ePortClass.getLoc());
        values.put(COLUMN_PNUM, ePortClass.getNums());
        values.put(COLUMN_WRKHT, ePortClass.getWrkht());
        values.put(COLUMN_EDU, ePortClass.getEdu());
        values.put(COLUMN_REF, ePortClass.getRefs());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_ePortfolio, null, values);
        db.close();
    }
    // implements the search/find functionality
    public ePortClass searchInfo(String perLocation) {
        String query = "SELECT * FROM " +
                TABLE_ePortfolio + " WHERE " + COLUMN_LOC +
                " = \"" + perLocation + "\"";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        ePortClass ePortClass = new ePortClass();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            ePortClass.setID(Integer.parseInt(cursor.getString(0)));
            ePortClass.setLoc(cursor.getString(1));
            ePortClass.setNums(Integer.parseInt(cursor.getString(2)));
            ePortClass.setWrkht(cursor.getString(1));
            ePortClass.setEdu(cursor.getString(1));
            ePortClass.setRefs(cursor.getString(1));
            cursor.close();
        } else {
            ePortClass = null;
        }
        db.close();
        return ePortClass;
    }
    // implements the delete dog functionality
    public boolean deleteInfo(String perLocation) {
        boolean result = false;
        String query = "SELECT * FROM " + TABLE_ePortfolio +
                " WHERE " + COLUMN_LOC + " = \"" + perLocation + "\"";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        ePortClass ePortClass = new ePortClass();
        if (cursor.moveToFirst()) {
            ePortClass.setID(Integer.parseInt(cursor.getString(0)));
            db.delete(TABLE_ePortfolio, COLUMN_ID + " = ?",
                    new String[] { String.valueOf(ePortClass.getID())});
            cursor.close();
            result = true;
        }
        db.close();
        return result;
    }
}