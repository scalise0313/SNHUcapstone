package ericscalise.cs360.gethired2day;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class LinkedInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linked_in);

    }

}
