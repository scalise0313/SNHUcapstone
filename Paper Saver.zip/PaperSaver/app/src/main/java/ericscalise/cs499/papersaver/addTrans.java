package ericscalise.cs499.papersaver;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class addTrans extends AppCompatActivity {

    EditText etDate,etCategory,etAmount;
    Button btnAdd,btnView;
    DatabaseHelper myDB;
    //Withdraw and deposit variables.
    //Integer wd;
    //Integer dp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trans);
        etAmount = findViewById(R.id.etAmount);
        etDate = findViewById(R.id.etDate);
        etCategory = findViewById(R.id.etCategory);
        btnAdd = findViewById(R.id.btnAdd);
        btnView = findViewById(R.id.btnView);
        myDB = new DatabaseHelper(this);

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(addTrans.this,myTrans.class);
                startActivity(intent);
            }

        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Date = etDate.getText().toString();
                String Cat = etCategory.getText().toString();
                String Amt = etAmount.getText().toString();
                if(Date.length() != 0 && Cat.length() != 0 && Amt.length() != 0){
                    AddData(Date, Cat, Amt);
                    etAmount.setText("");
                    etCategory.setText("");
                    etDate.setText("");
                }else{
                    Toast.makeText(addTrans.this,"You must put something in the text field!",Toast.LENGTH_LONG).show();
                }
            }
        });



    }


    public void AddData(String Date, String Cat, String Amt ){
        boolean insertData = myDB.addData(Date,Cat,Amt);

        if(insertData==true){
            Toast.makeText(addTrans.this,"Successfully Entered Transaction!",Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(addTrans.this,"Something went wrong :(.",Toast.LENGTH_LONG).show();
        }
    }
}
