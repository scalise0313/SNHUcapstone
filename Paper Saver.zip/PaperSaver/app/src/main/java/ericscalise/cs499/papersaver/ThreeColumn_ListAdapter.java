package ericscalise.cs499.papersaver;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class ThreeColumn_ListAdapter extends ArrayAdapter<User1> {

    private LayoutInflater mInflater;
    private ArrayList<User1> users;
    private int mViewResourceId;

    public ThreeColumn_ListAdapter(Context context, int textViewResourceId, ArrayList<User1> users) {
        super(context, textViewResourceId, users);
        this.users = users;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mViewResourceId = textViewResourceId;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = mInflater.inflate(mViewResourceId, null);

        User1 user = users.get(position);

        if (user != null) {
            TextView Date = convertView.findViewById(R.id.Date);
            TextView Cat = convertView.findViewById(R.id.Cat);
            TextView Amt = convertView.findViewById(R.id.Amt);
            if (Date != null) {
                Date.setText(user.getDate());
            }
            if (Cat != null) {
                Cat.setText((user.getCat()));
            }
            if (Amt != null) {
                Amt.setText((user.getAmt()));
            }
        }

        return convertView;
    }
}
