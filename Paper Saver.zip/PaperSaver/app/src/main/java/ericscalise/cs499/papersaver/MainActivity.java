package ericscalise.cs499.papersaver;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView fullName, email;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Establishing all of the ids for the buttons on the main screen
        final FloatingActionButton fab = findViewById(R.id.fab);
        final FloatingActionButton fab2 = findViewById(R.id.fab2);
        final FloatingActionButton fab3 = findViewById(R.id.fab3);
        final Button btn = findViewById(R.id.mytrans);
        final Button btnS = findViewById(R.id.scanrec);


        fullName = findViewById(R.id.profileName);
        email = findViewById(R.id.profileEmail);
        //Getting instances for Firbase connectivity
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();


        userId = fAuth.getCurrentUser().getUid();
        //retrieve registered user information
        FirebaseFirestore.setLoggingEnabled(true);
        DocumentReference documentReference = fStore.collection("users").document(userId);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {


                fullName.setText(documentSnapshot.getString("fName"));
                email.setText(documentSnapshot.getString("email"));

                //Floating action button code is below here:
                //Code for the contact us section of the app which allows users to email me directly.
                fab.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Snackbar.make(view, "Contact Us", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        Intent contactIntent = new Intent(MainActivity.this, Contact.class);
                        startActivity(contactIntent);
                    }
                });
                //Code for the rate us section of the app that once I publish to the app store will allow users to rate the mobile app. using try and catch logic.
                //FIXME this section needs to be updated once published.
                fab2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Snackbar.make(view, "Rate Us", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("https://play.google.com/store/apps/details?id=" + "com.android.chrome")));
                        } catch (ActivityNotFoundException e) {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                        }
                    }
                });
                //Code for the about us section of the app where users can see my mission statement and our purpose.
                fab3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Snackbar.make(view, "About Us", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        Intent aboutUsIntent = new Intent(MainActivity.this, AboutUs.class);
                        startActivity(aboutUsIntent);
                    }
                });
                //Code for the myTransactions button
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent myTintent = new Intent(MainActivity.this, myTrans.class);
                        startActivity(myTintent);
                    }
                });
                //Code for Scan reciepts button
                btnS.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent scanIn = new Intent(MainActivity.this, scan.class);
                        startActivity(scanIn);
                    }
                });
            }


        });

    }
    public void logout (View view){

        FirebaseAuth.getInstance().signOut();//logout
        finish();
        startActivity(new Intent(getApplicationContext(), Register.class));

    }
}


