package ericscalise.cs499.papersaver;

public class CurBal {

    private Integer Amt;

    public CurBal(Integer amt){

        Amt = amt;
    }


    public Integer getAmt() {
        return Amt;
    }

    public void setAmt(Integer amt) {
        Amt = amt;
    }
}
