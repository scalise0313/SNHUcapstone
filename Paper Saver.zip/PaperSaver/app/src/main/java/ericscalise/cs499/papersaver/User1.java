package ericscalise.cs499.papersaver;

/**
 * Created by Mitch on 2016-05-13. Modified by Eric Scalise on 2020-08-02
 */
public class User1 {

    private String Date;
    private String Cat;
    private String Amt;

    public User1(String date, String cat, String amt){
        Date = date;
        Cat = cat;
        Amt = amt;
    }

    public String getDate() { return Date; }

    public void setDate(String date) {
        Date = date;
    }

    public String getCat() {
        return Cat;
    }

    public void setCat(String cat) {
        Cat = cat;
    }

    public String getAmt() {
        return Amt;
    }

    public void setAmt(String amt) {
        Amt = amt;
    }
}
