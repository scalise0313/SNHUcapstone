package ericscalise.cs499.papersaver;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;



public class myTrans extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_trans);
        //EditText bal;
        final FloatingActionButton addTrans = findViewById(R.id.addTrans);
        DatabaseHelper myDB;
        ArrayList<User1> userList;
        //ArrayList<CurBal> balance;
        ListView listView;
        User1 user;
        //CurBal curBal;
        //Balance Logic TODO





        //FAB coding logic
        addTrans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Add a Transaction ", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                Intent addTransIntent = new Intent(myTrans.this, addTrans.class);
                startActivity(addTransIntent);
            }
        });
        //DATABASE logic

        myDB = new DatabaseHelper(this);
        userList = new ArrayList<>();
        Cursor data = myDB.getListContents();
        int numRows = data.getCount();
        if (numRows == 0) {
            Toast.makeText(myTrans.this, "The Database is empty  :(.", Toast.LENGTH_LONG).show();
            Intent addTintent = new Intent(myTrans.this, addTrans.class);
            startActivity(addTintent);
        } else {
            int i = 0;
            while (data.moveToNext()) {
                user = new User1(data.getString(1), data.getString(2), data.getString(3));
                userList.add(i, user);
                System.out.println(data.getString(1) + " " + data.getString(2) + " " + data.getString(3));
                System.out.println(userList.get(i).getDate());
                i++;
            }
            ThreeColumn_ListAdapter adapter = new ThreeColumn_ListAdapter(this, R.layout.activity_my_trans, userList);
            listView = findViewById(R.id.listView);
            listView.setAdapter(adapter);


        }
    }
}











